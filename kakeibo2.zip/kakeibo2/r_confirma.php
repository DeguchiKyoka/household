<?php
session_start();

//エラーの初期化
if(empty($_SESSION['forget_errorMessage'])){
    $_SESSION['forget_errorMessage'] = "";
}

//cheakの取得
if(!empty($_REQUEST["cheak"])){
    $cheak = $_REQUEST["cheak"];
}else{
    $cheak = 0;
}

//passwordの取得
if(!empty($_REQUEST["password"])){
    $password = $_REQUEST["password"];
}else{
    $password = 0;
}

//サニタイジング
function h($str) {
    return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
}

?>

<!doctype html>
<html lang="ja">

    <head>
        <meta charset="UTF-8">

        <link rel="stylesheet" type="text/css" media="all" href="./css/style.css">
        <title>残高入力確認画面</title>

    </head>

    <body>

        <!-- 全体の画面の大きさ -->
        <div id="body">
            <!-- ログイン -->
            <div class="center">
            <!-- テキスト -->
                <h1 class="c_text_comment">
                    <p>以下の表記で登録しますか？</p>
                </h1>
                <h2 class="c_con_comment">
                      <p>財布残高<br>
                        銀行残高<br>
                        その他残高<br>
                      </p>
                    </a>
                </h2>
                <h2 class="yes_comment">
                    <a href="r_confirma_s.php" style="text-decoration:none;"><p>はい</p></a>
                </h2>
                <h2 class="no_comment">
                    <a href="home.php" style="text-decoration:none;"><p>いいえ</p></a>
                </h2>

            </div>

        </div>

    </body>

</html>
