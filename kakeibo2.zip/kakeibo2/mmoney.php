<!DOCTYPE HTML>
<html lang="ja">
<head>
<title>支出</title>
</head>

<frameset cols="200,900,*">

  <frame src="mmonth.php" name="mmonth" title="支出月毎">
  <frame src="minput.php" name="minput" title="支出入力">
  <frame src="mhistory.php" name="history" title="入力履歴">

</frameset>

</html>
