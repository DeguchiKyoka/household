<?php
session_start();
$_SESSION['login_id'] = "";
$_SESSION['login_nicname'] = "";

//エラーの初期化
if(!empty($_SESSION['login_errorMessage'])){
    $errorMessage = $_SESSION['login_errorMessage'];
}else{
    $errorMessage = "";
}

//サニタイジング
function h($str) {
    return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
}

?>
<!doctype html>
<html lang="ja">

    <head>
        <meta charset="UTF-8">
        <title>収入月毎</title>
        <link rel="stylesheet" type="text/css" media="all" href="./css/style.css">
    </head>

    <body>
        <script type="text/javascript">
            function checkForm($this)
            {
                var str=$this.value;
                while(str.match(/[^A-Z^a-z\d\-]/))
                {
                    str=str.replace(/[^A-Z^a-z\d\-]/,"");
                }
                $this.value=str;
            }
        </script>

        <!-- 全体の画面の大きさ -->
        <div id="body">
            <!-- ログイン -->
            <div class="center">

                <h2 class="month_comment">
                    <a href="mJan.php" target="minput" style="text-decoration:none;"><p>1月</p></a>
                </h2>

                <h2 class="month_comment2">
                    <a href="mFeb.php" target="minput" style="text-decoration:none;"><p>2月</p></a>
                </h2>

                <h2 class="month_comment3">
                    <a href="mMar.php" target="minput" style="text-decoration:none;"><p>3月</p></a>
                </h2>

                <h2 class="month_comment4">
                    <a href="mApr.php" target="minput" style="text-decoration:none;"><p>4月</p></a>
                </h2>

                <h2 class="month_comment5">
                    <a href="mMay.php" target="minput" style="text-decoration:none;"><p>5月</p></a>
                </h2>

                <h2 class="month_comment6">
                    <a href="mJun.php" target="minput" style="text-decoration:none;"><p>6月</p></a>
                </h2>

                <h2 class="month_comment7">
                    <a href="mJul.php" target="minput" style="text-decoration:none;"><p>7月</p></a>
                </h2>

                <h2 class="month_comment8">
                    <a href="mAug.php" target="minput" style="text-decoration:none;"><p>8月</p></a>
                </h2>

                <h2 class="month_comment9">
                    <a href="mSep.php" target="minput" style="text-decoration:none;"><p>9月</p></a>
                </h2>

                <h2 class="month_comment10">
                    <a href="mOct.php" target="minput" style="text-decoration:none;"><p>10月</p></a>
                </h2>

                <h2 class="month_comment11">
                    <a href="mNov.php" target="minput" style="text-decoration:none;"><p>11月</p></a>
                </h2>

                <h2 class="month_comment12">
                    <a href="mDec.php" target="minput" style="text-decoration:none;"><p>12月</p></a>
                </h2>

            </div>

        </div>

    </body>

</html>
