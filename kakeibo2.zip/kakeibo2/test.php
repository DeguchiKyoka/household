<?php

//変数
$db['host'] = "localhost"; //DBサーバのURL
$db['user'] = "phpuser"; //ユーザ名
$db['pass'] = "pass"; //ユーザ名のパスワード
$db['dbname'] = "phptest"; //データベース名
$db['type'] = "mysql";

 ?>
 <!doctype html>
 <html>
  <head>
    <meta charset="utf-8">
    <title>test</title>
  </head>

  <body>
    <?php
      try{
          //データベース接続
          $pdo = new
          PDO($db['type'].':host='.$db['host'].';dbname='.$db['dbname'].';charset=utf8',$db['user'],$db['pass']);
          $pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
          $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
          echo('PDOクラスによる接続に成功しました。');

      }catch(PDOException $exception){

      }
    ?>
  </body>
</html>
