<?php
session_start();
$_SESSION['login_id'] = "";
$_SESSION['login_nicname'] = "";


?>
<!doctype html>
<html lang="ja">

    <head>
        <meta charset="UTF-8">
        <title>1月収入</title>
        <link rel="stylesheet" type="text/css" media="all" href="./css/style.css">
    </head>

    <body>
        <!-- 全体の画面の大きさ -->
        <div id="body">
            <!-- ログイン -->
            <div class="center">
                
                <?php
                for($i=0;$i<100;$i++){
                    echo('<h2 class="pmonth_comment" style="top: '.($i*200).'px;">');
                    echo('<p>日にち<br>');
                    echo('収入金額<br>');
                    echo('<a href="Details.php" style="text-decoration:none;" >');
                    echo('詳細<br>');
                    echo('</a>');
                    echo('</p>');
                    echo('</h2>');
                }
                ?>
            </div>
        </div>
    </body>
</html>
