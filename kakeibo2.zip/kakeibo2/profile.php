<?php
session_start();
$_SESSION['login_id'] = "";
$_SESSION['login_nicname'] = "";

//エラーの初期化
if(!empty($_SESSION['login_errorMessage'])){
    $errorMessage = $_SESSION['login_errorMessage'];
}else{
    $errorMessage = "";
}

//サニタイジング
function h($str) {
    return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
}

   ?>

<!doctype html>
<html lang="ja">

    <head>
        <meta charset="UTF-8">
        <title>プロフィール</title>
        <link rel="stylesheet" type="text/css" media="all" href="./css/style.css">
    </head>

    <body>

        <script type="text/javascript">
            function checkForm($this)
            {
                var str=$this.value;
                while(str.match(/[^A-Z^a-z\d\-]/))
                {
                    str=str.replace(/[^A-Z^a-z\d\-]/,"");
                }
                $this.value=str;
            }
        </script>

        <!-- 全体の画面の大きさ -->

        <div id="body">

          <div class="menu_img">
            <a href="home.php"><img class="img_back" src="image/button/back.png"></a>
          </div>

            <!-- ログイン -->
            <div class="center">

                <!-- テキスト -->
                <form method="post" action="./cheak/login_c.php">

                    <h1 class="profile_comment">
                    <p>あなたのプロフィール</p>
                  </h1>

                <h2 class="profile_comment1">
                    <p>姓</p>
                </h2>
                <h2 class="profile_comment2">
                    <p>名</p>
                </h2>
                <h2 class="profile_comment3">
                    <p>性別</p></a>
                </h2>
                <h2 class="profile_comment4">
                    <p>職業</p></a>
                </h2>
                <h2 class="profile_comment5">
                    <p>生年月日</p></a>
                </h2>
                <h2 class="profile_comment6">
                    <div class="success"><a href="profile_s.php" style="text-decoration:none;"><p>決定</p></a></div>
                </h2>

                <form method="post" action="./cheak/login_c.php">
                  <input class="profile_comment_text1" type="text" name="user_id"  placeholder="苗字を記入してください" onInput="checkForm(this)" maxlength="20">
                  <input class="profile_comment_text2" type="text" name="user_id"  placeholder="名前を記入してください" onInput="checkForm(this)" maxlength="20">
                  <input class="profile_comment_text3" type="text" name="user_id"  placeholder="性別を記入してください" onInput="checkForm(this)" maxlength="20">
                  <input class="profile_comment_text4" type="text" name="user_id"  placeholder="職業を記入してください" onInput="checkForm(this)" maxlength="20">
                  <input class="profile_comment_text5" type="text" name="user_id"  placeholder="生年月日を記入してください" onInput="checkForm(this)" maxlength="20">
                </form>

            </div>

        </div>

    </body>

</html>
