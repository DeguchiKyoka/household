<?php
session_start();

?>
<!doctype html>
<html lang="ja">

    <head>
        <meta charset="UTF-8">
        <title>1月収入</title>
        <link rel="stylesheet" type="text/css" media="all" href="./css/style.css">
    </head>

    <body>
        <!-- 全体の画面の大きさ -->
        <div id="body">
            <!-- ログイン -->
            <div class="center">

                <h2 class="pmonth_comment">
                    <p>日にち<br/>
                        収入金額<br/>
                        <a href="Details.php" style="text-decoration:none;" >
                            詳細<br/></a>
                    </p>
                </h2>

                <h2 class="pmonth_comment2">
                    <p>日にち<br>
                        収入金額<br>
                        <a href="Details.php" style="text-decoration:none;">
                            詳細<br></a>
                    </p>
                </h2>

                <h2 class="pmonth_comment3">
                    <p>日にち<br>
                        収入金額<br>
                        <a href="Details.php" style="text-decoration:none;">
                            詳細<br></a>
                    </p>
                </h2>

                <h2 class="pmonth_comment4">
                    <p>日にち<br>
                        収入金額<br>
                        <a href="Details.php" style="text-decoration:none;">
                            詳細<br></a>
                    </p>
                </h2>

                <h2 class="pmonth_comment5">
                    <p>日にち<br>
                        収入金額<br>
                        <a href="Details.php" style="text-decoration:none;">
                            詳細<br></a>
                    </p>
                </h2>
            </div>
        </div>
    </body>
</html>
