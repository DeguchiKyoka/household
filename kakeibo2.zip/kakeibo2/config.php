<?php
session_start();
$_SESSION['login_id'] = "";
$_SESSION['login_nicname'] = "";

//エラーの初期化
if(!empty($_SESSION['login_errorMessage'])){
    $errorMessage = $_SESSION['login_errorMessage'];
}else{
    $errorMessage = "";
}

//サニタイジング
function h($str) {
    return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
}

?>
<!doctype html>
<html lang="ja">

    <head>
        <meta charset="UTF-8">
        <title>設定</title>
        <link rel="stylesheet" type="text/css" media="all" href="./css/style.css">
    </head>

    <body>
        <script type="text/javascript">
            function checkForm($this)
            {
                var str=$this.value;
                while(str.match(/[^A-Z^a-z\d\-]/))
                {
                    str=str.replace(/[^A-Z^a-z\d\-]/,"");
                }
                $this.value=str;
            }
        </script>

        <!-- 全体の画面の大きさ -->
        <div id="body">
            <!-- ログイン -->
            <div class="center">

                <!-- テキスト -->
                <h2 class="config_comment">
                    <a href="rogout.php" target="_blank" style="text-decoration:none;"><p>ログアウト</p></a>
                </h2>

                <h2 class="config_comment2">
                    <a href="changeid.php" target="_blank" style="text-decoration:none;"><p>ID/パスワード変更</p></a>
                </h2>

                <h2 class="config_comment3">
                    <a href="profile.php" target="_blank" style="text-decoration:none;"><p>プロフィール作成</p></a>
                </h2>

                <h2 class="config_comment4">
                    <a href="deletedata.php" target="_blank" style="text-decoration:none;"><p>データ削除</p></a>
                </h2>

            </div>

        </div>

    </body>

</html>
