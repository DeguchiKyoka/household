<?php
session_start();
$_SESSION['entry_errorMessage'] = "";
$_SESSION['login_id'] = "";
$_SESSION['nickname'] = "";

//変数
$db['host'] = "localhost";  // DBサーバのURL
$db['user'] = "kakeibo";  // ユーザー名
$db['pass'] = "123";  // ユーザー名のパスワード
$db['dbname'] = "phptest";  // データベース名
$db['type'] = "mysql";

$count = 0;

$url = '../home.php';

//データベース接続
$pdo = new PDO($db['type'].':host='.$db['host'].';dbname='.$db['dbname'].';charset=utf8',$db['user'],$db['pass']);
$pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
$pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
echo('PDOクラスによる接続に成功しました。');

// POSTの入力チェック
if (empty($_POST['user_id'])) {
    $_SESSION['entry_errorMessage'] = "入力されていない項目があります。";
    $url = '../index.php';
}else{
    $count++;
}

if (empty($_POST['password'])) {
    $_SESSION['entry_errorMessage'] = "入力されていない項目があります。";
    $url = '../index.php';
}else{
    $count++;
}


//ログイン確認
if($count == 2){
    //表示をするSQL作成
    $stmt = $pdo->query("SELECT * FROM user_test");
    //while文でデータベースの中身を取得
    while($row = $stmt -> fetch(PDO::FETCH_ASSOC)) {
        if($_POST['user_id'] == $row["user_id"]){
            if($_POST['password'] == $row["password"]){
                
                $_SESSION['login_id'] = $row["user_id"];
                $_SESSION['nickname'] = $row["nickname"];
                $count++;
            }
        }
    }
}

if($count != 3){
    $url = '../index.php';
}

header( "Location:".$url );

?>