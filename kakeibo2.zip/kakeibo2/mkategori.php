<?php
session_start();
$_SESSION['login_id'] = "";
$_SESSION['login_nicname'] = "";

//エラーの初期化
if(!empty($_SESSION['login_errorMessage'])){
    $errorMessage = $_SESSION['login_errorMessage'];
}else{
    $errorMessage = "";
}

//サニタイジング
function h($str) {
    return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
}

?>
<!doctype html>
<html lang="ja">

    <head>
        <meta charset="UTF-8">
        <title>1月収入</title>
        <link rel="stylesheet" type="text/css" media="all" href="./css/style.css">
    </head>

    <body>
        <script type="text/javascript">
            function checkForm($this)
            {
                var str=$this.value;
                while(str.match(/[^A-Z^a-z\d\-]/))
                {
                    str=str.replace(/[^A-Z^a-z\d\-]/,"");
                }
                $this.value=str;
            }
        </script>

        <!-- 全体の画面の大きさ -->
        <div id="body">
            <!-- ログイン -->
            <div class="center">

                <h2 class="kategori_comment">
                      <p>追加するカテゴリを入力してください</p>
                    </a>
                </h2>

                <h2 class="kategori_comment3">
                    <a href="kategori_s.php" target="pinput" style="text-decoration:none;"><p>カテゴリを登録する</p></a>
                </h2>

                <div class="menu_img">
                <p><a href="home.php" target="_top"><img class="kategori_back" src="image/button/back.png"></a></p>
                </div>

                <!-- form -->
                <form method="post" action="./cheak/entry_c.php">
                    <input class="kategori_comment2" type="text" name="nickname" maxlength="20">
　　　　　　　　　</form>

            </div>

        </div>

    </body>

</html>
