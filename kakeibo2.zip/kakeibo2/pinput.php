<?php
session_start();
$_SESSION['login_id'] = "";

?>

<!doctype html>
<html lang="ja">

    <head>

        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" media="all" href="./css/style.css">
        <title>収入入力画面</title>

    </head>

    <body>
        <script type="text/javascript">
            function checkForm($this)
            {
                var str=$this.value;
                while(str.match(/[^A-Z^a-z\d\-]/))
                {
                    str=str.replace(/[^A-Z^a-z\d\-]/,"");
                }
                $this.value=str;
            }
        </script>

        <!-- 全体の画面の大きさ -->
        <div class="menu_img">
          <p><a href="pkategori.php" target="pinput"><img class="input_button" src="image/button/plus.png"></a></p>
        </div>

        <div id="body">
            <!-- ログイン -->
            <div class="center">

                <!-- テキスト -->
                <h2 class="input_comment">
                    <p>金額</p>
                </h2>

                <h2 class="input_comment1">
                    <p>日にち</p>
                </h2>

                <h2 class="input_comment2">
                    <p>カテゴリ</p>
                </h2>
                <h2 class="input_comment3">
                    <p>メモ</p>
                </h2>

                

                <!-- form -->
                <form method="post" action="./p_confirma.php">
                    <input class="pinput_comment_text" type="text" name="money"  placeholder="収入金額を入力してください"  maxlength="20">
                    <select class="pinput_comment_text1" name="year">
                        <option value="2019年">2019年</option>
                        <option value="2018年">2018年</option>
                        <option value="2017年">2017年</option>
                        <option value="2016年">2016年</option>
                    </select>
                    <select class="pinput_comment_text2" name="month">
                        <option value="1月">1月</option>
                        <option value="2月">2月</option>
                        <option value="3月">3月</option>
                        <option value="4月">4月</option>
                        <option value="5月">5月</option>
                        <option value="6月">6月</option>
                        <option value="7月">7月</option>
                        <option value="8月">8月</option>
                        <option value="9月">9月</option>
                        <option value="10月">10月</option>
                        <option value="11月">11月</option>
                        <option value="12月">12月</option>
                    </select>
                    <select class="pinput_comment_text3" name="day">
                        <option value="1日">1日</option>
                        <option value="2日">2日</option>
                        <option value="3日">3日</option>
                        <option value="4日">4日</option>
                        <option value="5日">5日</option>
                        <option value="6日">6日</option>
                        <option value="7日">7日</option>
                        <option value="8日">8日</option>
                        <option value="9日">9日</option>
                        <option value="10日">10日</option>
                        <option value="11日">11日</option>
                        <option value="12日">12日</option>
                        <option value="13日">13日</option>
                        <option value="14日">14日</option>
                        <option value="15日">15日</option>
                        <option value="16日">16日</option>
                        <option value="17日">17日</option>
                        <option value="18日">18日</option>
                        <option value="19日">19日</option>
                        <option value="20日">20日</option>
                        <option value="21日">21日</option>
                        <option value="22日">22日</option>
                        <option value="23日">23日</option>
                        <option value="24日">24日</option>
                        <option value="25日">25日</option>
                        <option value="26日">26日</option>
                        <option value="27日">27日</option>
                        <option value="28日">28日</option>
                        <option value="29日">29日</option>
                        <option value="30日">30日</option>
                        <option value="31日">31日</option>
                    </select>
                    <select class="pinput_comment_text4" name="a">
                        <option value="給与所得">給与所得</option>
                        <option value="立替金返済">立替金返済</option>
                        <option value="賞与">賞与</option>
                        <option value="臨時収入">臨時収入</option>
                        <option value="事業所得">事業所得</option>
                    </select>
                    <textarea name="memo" class="input_comment_text5" cols="50" rows="10"  maxlength="100">
                    </textarea>
                    <input type="submit" class="pinput_comment" style="text-decoration:none;" value="収入を登録する">
                </form>

            </div>

        </div>

    </body>

</html>
