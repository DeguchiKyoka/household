<?php
session_start();
$_SESSION['login_id'] = "";

?>

<!doctype html>
<html lang="ja">

    <head>

        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" media="all" href="./css/style.css">
        <title>アカウント作成</title>

    </head>

    <body>
        <script type="text/javascript">
            function checkForm($this)
            {
                var str=$this.value;
                while(str.match(/[^A-Z^a-z\d\-]/))
                {
                    str=str.replace(/[^A-Z^a-z\d\-]/,"");
                }
                $this.value=str;
            }
        </script>

        <div class="menu_img">
          <a href="index.php"><img class="img_back" src="image/button/back.png"></a>
        </div>

        <!-- 全体の画面の大きさ -->

        <div id="body">
            <!-- ログイン -->
            <div class="center">

                <!-- テキスト -->
                <h1 class="entry_comment">
                    <p>アカウント作成</p>
                </h1>

                <h2 class="entry_comment1">
                    <p>ニックネーム</p>
                </h2>

                <h2 class="entry_comment2">
                    <p>ID</p>
                </h2>

                <h2 class="entry_comment3">
                    <p>パスワード</p>
                </h2>

                <h2 class="entry_comment4">
                    <p>パスワード再入力</p>
                </h2>

                <h2 class="entry_comment5">
                    <p>秘密の質問</p>
                </h2>

                <h2 class="entry_comment6">
                    <p>秘密の答え</p>
                </h2>
                <h2 class="entry_comment7">
                    <a href="remoney.php" style="text-decoration:none;"><p>決定</p></a>
                </h2>

                <!-- form -->
                <form method="post" action="./cheak/entry_c.php">
                    <input class="entry_comment_text1" type="text" name="nickname"  placeholder="ニックネームを入力してください"  maxlength="20">
                    <input class="entry_comment_text2" type="text" name="user_id" placeholder="IDを入力してください" onInput="checkForm(this)" maxlength="20">
                    <input class="entry_comment_text3" type="password" name="password"  placeholder="パスワードを入力してください" onInput="checkForm(this)" maxlength="20">
                    <input class="entry_comment_text4" type="password" name="repassword" placeholder="もう一度パスワードを入力してください" onInput="checkForm(this)" maxlength="20">
                    <select class="entry_comment_text5" name="secret_question">
                        <option value="1">好きな食べもの</option>
                        <option value="2">飼っていたペットの名前</option>
                        <option value="3">お気に入りの映画</option>
                        <option value="4">子供のころ所属していた部活</option>
                    </select>
                    <input class="entry_comment_text6" type="text" name="secret_answer" placeholder="秘密の答えを入力してください"  maxlength="50">
                </form>

            </div>

        </div>

    </body>

</html>
