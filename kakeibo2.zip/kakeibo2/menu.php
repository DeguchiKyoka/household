<?php
session_start();

//エラーの初期化
if(!empty($_SESSION['login_errorMessage'])){
    $errorMessage = $_SESSION['login_errorMessage'];
}else{
    $errorMessage = "";
}

//サニタイジング
function h($str) {
    return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
}

?>

<!doctype html>
<html lang="ja">

    <head>
        <meta charset="UTF-8">
        <title>メニュー</title>
        <link rel="stylesheet" type="text/css" media="all" href="./css/style.css" target="top">
    </head>

    <body>

        <script type="text/javascript">
            function checkForm($this)
            {
                var str=$this.value;
                while(str.match(/[^A-Z^a-z\d\-]/))
                {
                    str=str.replace(/[^A-Z^a-z\d\-]/,"");
                }
                $this.value=str;
            }
        </script>

        <div class="menu_img">
            <p><a href="top.php" target="top"><img class="img_home" src="image/button/home.png"></a></p>
            <p><a href="pmoney.php" target="top"><img class="img_pmoney" src="image/button/pmoney.png"></a></p>
            <p><a href="mmoney.php" target="top"><img class="img_mmoney" src="image/button/mmoney.png"></a></p>
            <p><a href="rmoney.php" target="top"><img class="img_rmoney" src="image/button/rmoney.png"></a></p>
            <p><a href="karendar.php" target="top"><img class="img_karendar" src="image/button/karendar.png"></a></p>
            <p><a href="dentaku.php" target="top"><img class="img_dentaku" src="image/button/dentaku.png"></a></p>
            <p><a href="config.php" target="top"><img class="img_config" src="image/button/config.png"></a></p>
            <p><a href="index.php" target="_top"><img class="img_back" src="image/button/back.png"></a></p>
        </div>

        <!-- 全体の画面の大きさ -->
        <div id="body">
            <!-- ログイン -->
            <div class="center">

                <!-- テキスト -->
                <form method="post" action="./cheak/login_c.php">

                    <h1 class="menu_comment">
                        <p>ようこそ！<?php echo($_SESSION['nickname']); ?>さん<br></p>
                    </h1>

                    <h2 class="menu_home">
                        <a href="top.php" target="top" style="text-decoration:none;"><p>HOME</p></a>
                    </h2>
                    <h2 class="menu_pmoney">
                        <a href="pmoney.php" target="top" style="text-decoration:none;"><p>収入</p></a>
                    </h2>
                    <h2 class="menu_mmoney">
                        <a href="mmoney.php" target="top" style="text-decoration:none;"><p>支出</p></a>
                    </h2>
                    <h2 class="menu_rmoney">
                        <a href="rmoney.php" target="top" style="text-decoration:none;"><p>残高</p></a>
                    </h2>
                    <h2 class="menu_karendar">
                        <a href="karendar.php" target="top" style="text-decoration:none;"><p>カレンダー</p></a>
                    </h2>
                    <h2 class="menu_dentaku">
                        <a href="dentaku.php" target="top" style="text-decoration:none;"><p>電卓</p></a>
                    </h2>
                    <h2 class="menu_config">
                        <a href="config.php" target="top" style="text-decoration:none;"><p>設定</p></a>
                    </h2>
                </form>

            </div>

        </div>

    </body>

</html>

