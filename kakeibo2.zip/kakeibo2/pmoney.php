<!DOCTYPE HTML>
<html lang="ja">
<head>
<title>収入</title>
</head>

<frameset cols="200,900,*">

<div class="example2">
<frame src="pmonth.php" name="pmonth" title="収入月毎" noresize>
<frame src="pinput.php" name="pinput" title="収入入力" noresize>
<frame src="phistory.php" name="history" title="入力履歴" noresize>
</div>

</frameset>

</html>
