<?php
session_start();

//サニタイジング
function h($str) {
    return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
}

?>

<!doctype html>
<html lang="ja">

    <head>

        <meta charset="UTF-8">
    　  <link rel="stylesheet" type="text/css" media="all" href="./css/style.css">
        <title>パスワードをお忘れの方</title>

    </head>

    <body>
      <div id="container">
      <div id="wrapper">
        <script type="text/javascript">
            function checkForm($this)
            {
                var str=$this.value;
                while(str.match(/[^A-Z^a-z\d\-]/))
                {
                    str=str.replace(/[^A-Z^a-z\d\-]/,"");
                }
                $this.value=str;
            }
        </script>

        <div class="menu_img">
          <a href="index.php"><img class="img_back" src="image/button/back.png"></a>
        </div>

        <!-- 全体の画面の大きさ -->

        <div id="body">
            <!-- ログイン -->
            <div class="center">

                <!-- テキスト -->
                <form method="post" action="./cheak/forget_c.php">
                <h1 class="login_comment">
                    <p>パスワードをお忘れの方</p>
                </h1>

                <h2 class="login_comment1">
                    <p>ID</p>
                </h2>

                  <h2 class="forget_comment1">
                    <p>秘密の質問</p>
                </h2>
                  <h2 class="forget_comment2">
                    <p>秘密の答え</p>
                </h2>

                <h2 class="forget_comment3">
                    <a href="passhow.php" style="text-decoration:none;"><p>決定</p></a>
                </h2>

                <form method="post" action="./cheak/forget_c.php">
                  <input class="login_comment_text1" type="text" name="user_id"  placeholder="IDを入力してください" onInput="checkForm(this)" maxlength="20">
                  <select class="forget_comment_select1" name="secret_question">
                    <option value="1">好きな食べもの</option>
                    <option value="2">飼っていたペットの名前</option>
                    <option value="3">お気に入りの映画</option>
                    <option value="4">子供のころ所属していた部活</option>
                  </select>
                  <input class="forget_comment_text" type="text" name="secret_answer" placeholder="秘密の答えを入力してください"  maxlength="50">
                </form>

            </div>

        </div>

    </body>

</html>
