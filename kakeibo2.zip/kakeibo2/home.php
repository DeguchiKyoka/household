<?php
?><!DOCTYPE html>
<html lang="ja">
    <head>
        <meta charset="utf-8">
        <title>家計簿システム</title>
        <link rel="stylesheet" type="text/css" media="all" href="./css/style.css">
    </head>

    <div class="example">
        <frameset rows="250,*" frameborder="NO" border="0">
            <frame name="menu" src="menu.php" scrolling="no">
            <frameset rows="800,*" frameborder="NO" border="0">
                <frame src="top.php" name="top" scrolling="no">
            </frameset>
        </frameset>
    </div>

</html>
