
<!doctype html>
<html lang="ja">

    <head>
        <meta charset="UTF-8">
        <title>カレンダー</title>
        <link rel="stylesheet" type="text/css" media="all" href="./css/style.css">
    </head>

    <body>
        <div class="karendar">
            <?php
            //年月の指定があれば
            if(isset($_POST['yyyy']) && $_POST['yyyy'] != '' && isset($_POST['mm']) && $_POST['mm'] != ''){
                $yyyy = $_POST['yyyy'];
                $mm =   $_POST['mm'];
                //指定がなければ本日の年月
            }else{
                $yyyy = date('Y');
                $mm =   date('m');
            }
            $dd = 1;
            ?>

            <form align='center' method="POST" action="<?php $_SERVER['PHP_SELF']; ?>">

                <select name="yyyy">
                    <?php
                    for($i = 1999; $i <= 2100; $i++){
                        echo '<option value="'.$i.'"'; if($i == $yyyy) echo ' selected'; echo '>'.$i.'</option>'."\n";
                    }
                    ?>
                </select>年

                <select name="mm">
                    <?php
                    for($i = 1; $i <= 12; $i++){
                        echo '<option value="'.$i.'"'; if($i == $mm) echo ' selected'; echo '>'.$i.'</option>'."\n";
                    }
                    ?>
                </select>月
                <input type="submit" value="決定">

            </form>

            <?php
            //カレンダー関数
            function calendar($yyyy, $mm, $dd){

                //選択日のタイムスタンプ
                $iSctDayTimeStamp = mktime(0,0,0,$mm,$dd,$yyyy);
            ?>
            <table align='center' border ="1" bgcolor="#cccccc" cellspacing="1" width="700" height="500">
                <?php

                ### 月列
                if(checkdate($mm, 1, $yyyy)){
                ?>
                <tr>
                    <td align="center" bgcolor="#ffffff" colspan="7">
                        <?php echo $yyyy; ?>年<?php echo $mm; ?>月
                    </td>
                </tr>
                <?php
                }
                ?>

                <?php
                ### 曜日列
                ?>
                <tr>
                    <td text align='center' bgcolor="#ffd0d0">日</td>
                    <td text align='center' bgcolor="#f7ffde">月</td>
                    <td text align='center' bgcolor="#f7ffde">火</td>
                    <td text align='center' bgcolor="#f7ffde">水</td>
                    <td text align='center' bgcolor="#f7ffde">木</td>
                    <td text align='center' bgcolor="#f7ffde">金</td>
                    <td text align='center' bgcolor="#def9ff">土</td>
                </tr>

                <?php
                ### 日付列

                //曜日NO
                $iWNoMthFst = date('w',mktime(0,0,0,$mm,1,$yyyy));//0:日～6:土

                //日付が始まる前の空白
                for($iFstWeekBnk = 0 ;$iFstWeekBnk < $iWNoMthFst ;$iFstWeekBnk++){
                ?>
                <td align='center' bgcolor='#FFFFFF'> </td>
                <?php
                }

                //日付記述 年月日の妥当性がtrueであればループ
                for($dd = 1 ;checkdate($mm, $dd, $yyyy); $dd++ ){

                    //本日のタイムスタンプ
                    $iTodayTimeStamp = mktime(0,0,0,date('m'),date('d'),date('Y'));
                    //指定年月のループ日付のタイムスタンプ
                    $iDisplayDaysTimeStamp = mktime(0,0,0,$mm,$dd,$yyyy);

                    //1日が日曜日のとき　1　8　15　22　29が　== 1となる
                    //日曜日
                    if(($dd+$iWNoMthFst)%7 == 1){
                        echo '<tr><td align="center" bgcolor="';
                        //本日
                        if($iTodayTimeStamp == $iDisplayDaysTimeStamp) echo '#ffe293';
                        else echo '#ffd0d0';
                ?>
                "><?php echo $dd; ?>
                <?php echo '</td>'; ?>
                <?php
                    }
                    //土曜日
                    elseif(($dd+$iWNoMthFst)%7 == 0){
                        echo '<td align="center" bgcolor="';
                        //本日
                        if($iTodayTimeStamp == $iDisplayDaysTimeStamp) echo '#ffe293';
                        else echo '#def9ff';
                ?>
                "><?php echo $dd; ?>
                <?php echo '</td></tr>'; ?>
                <?php
                    }
                    //平日
                    else{
                        echo '<td align="center" bgcolor="';
                        //本日
                        if($iTodayTimeStamp == $iDisplayDaysTimeStamp) echo '#ffe293';
                        else echo '#ffffff';
                ?>
                "><?php echo $dd; ?>
                <?php echo '</td>'; ?>
                <?php
                    }
                }
                //指定月最終日の曜日$ddは32になっている
                $iWNoMthEnd = date('w',mktime(0,0,0,$mm,$dd,$yyyy));
                if($iWNoMthEnd != 0){
                    //もし32が日曜日すなわち0ならそれで終了
                    for($iWeekBlank = 0 ; $iWeekBlank < 7-$iWNoMthEnd; $iWeekBlank++){
                        //0以外は が必要
                        echo '<td align="center" bgcolor="#FFFFFF"> </td>';
                    }
                }
                ?>
                <?php echo '</tr>'; ?>
            </table>

            <?php
            }// end function
            ?>

            <?php
            //カレンダー表示
            calendar($yyyy, $mm, $dd);
            ?>
        </div>
    </body>

</html>
