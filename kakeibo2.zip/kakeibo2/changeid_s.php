<?php
session_start();

//エラーの初期化
if(empty($_SESSION['forget_errorMessage'])){
    $_SESSION['forget_errorMessage'] = "";
}

//cheakの取得
if(!empty($_REQUEST["cheak"])){
    $cheak = $_REQUEST["cheak"];
}else{
    $cheak = 0;
}

//passwordの取得
if(!empty($_REQUEST["password"])){
    $password = $_REQUEST["password"];
}else{
    $password = 0;
}

//サニタイジング
function h($str) {
    return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
}

?>

<!doctype html>
<html lang="ja">

    <head>
        <meta charset="UTF-8">

        <link rel="stylesheet" type="text/css" media="all" href="./css/style.css">
        <title>アカウント変更確認画面</title>

    </head>

    <body>

        <!-- 全体の画面の大きさ -->
        <div id="body">
            <!-- ログイン -->
            <div class="center">
            <!-- テキスト -->
                <h1 class="text_comment">
                    <p>アカウントを変更しました。</p>
                </h1>

                <h2 class="login_comment3">
                    <a href="index.php" style="text-decoration:none;"><p>画面を閉じる</p></a>
                </h2>

            </div>

        </div>

    </body>

</html>
