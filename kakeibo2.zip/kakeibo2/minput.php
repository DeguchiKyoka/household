<?php
session_start();
$_SESSION['login_id'] = "";

?>

<!doctype html>
<html lang="ja">

    <head>

        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" media="all" href="./css/style.css">
        <title>収入入力画面</title>

    </head>

    <body>
        <script type="text/javascript">
            function checkForm($this)
            {
                var str=$this.value;
                while(str.match(/[^A-Z^a-z\d\-]/))
                {
                    str=str.replace(/[^A-Z^a-z\d\-]/,"");
                }
                $this.value=str;
            }
        </script>

        <!-- 全体の画面の大きさ -->
        <div class="menu_img">
          <p><a href="mkategori.php" target="minput"><img class="input_button" src="image/button/plus.png"></a></p>
        </div>

        <div id="body">
            <!-- ログイン -->
            <div class="center">

                <!-- テキスト -->
                <h2 class="input_comment">
                    <p>金額</p>
                </h2>

                <h2 class="input_comment1">
                    <p>日にち</p>
                </h2>

                <h2 class="input_comment2">
                    <p>カテゴリ</p>
                </h2>
                <h2 class="input_comment3">
                    <p>メモ</p>
                </h2>

                <h2 class="minput_comment">
                    <a href="m_confirma.php" target="_blank" style="text-decoration:none;"><p>支出を登録する</p></a>
                </h2>

                <!-- form -->
                <form method="post" action="./cheak/entry_c.php">
                    <input class="minput_comment_text" type="text" name="nickname"  placeholder="支出金額を入力してください"  maxlength="20">
                    <select class="minput_comment_text1" name="secret_question">
                        <option value="2019年">2019年</option>
                        <option value="2018年">2018年</option>
                        <option value="2017年">2017年</option>
                        <option value="2016年">2016年</option>
                    </select>
                    <select class="minput_comment_text2" name="secret_question">
                        <option value="1月">1月</option>
                        <option value="2月">2月</option>
                        <option value="3月">3月</option>
                        <option value="4月">4月</option>
                        <option value="5月">5月</option>
                        <option value="6月">6月</option>
                        <option value="7月">7月</option>
                        <option value="8月">8月</option>
                        <option value="9月">9月</option>
                        <option value="10月">10月</option>
                        <option value="11月">11月</option>
                        <option value="12月">12月</option>
                    </select>
                    <select class="minput_comment_text3" name="secret_question">
                        <option value="1日">1日</option>
                        <option value="2日">2日</option>
                        <option value="3日">3日</option>
                        <option value="4日">4日</option>
                        <option value="5日">5日</option>
                        <option value="6日">6日</option>
                        <option value="7日">7日</option>
                        <option value="8日">8日</option>
                        <option value="9日">9日</option>
                        <option value="10日">10日</option>
                        <option value="11日">11日</option>
                        <option value="12日">12日</option>
                        <option value="13日">13日</option>
                        <option value="14日">14日</option>
                        <option value="15日">15日</option>
                        <option value="16日">16日</option>
                        <option value="17日">17日</option>
                        <option value="18日">18日</option>
                        <option value="19日">19日</option>
                        <option value="20日">20日</option>
                        <option value="21日">21日</option>
                        <option value="22日">22日</option>
                        <option value="23日">23日</option>
                        <option value="24日">24日</option>
                        <option value="25日">25日</option>
                        <option value="26日">26日</option>
                        <option value="27日">27日</option>
                        <option value="28日">28日</option>
                        <option value="29日">29日</option>
                        <option value="30日">30日</option>
                        <option value="31日">31日</option>
                    </select>
                    <select class="minput_comment_text4" name="secret_question">
                        <option value="食費">食費</option>
                        <option value="日用雑貨">日用雑貨</option>
                        <option value="交通">交通</option>
                        <option value="交際費">交際費</option>
                        <option value="エンタメ">エンタメ</option>
                        <option value="教育・教養">教育・教養</option>
                        <option value="美容・衣服">美容・衣服</option>
                    　　<option value="医療・保健">医療・保健</option>
                        <option value="通信">通信</option>
                        <option value="水道・光熱">水道・光熱</option>
                        <option value="住まい">住まい</option>
                        <option value="クルマ">クルマ</option>
                        <option value="税金">税金</option>
                        <option value="大型出費">大型出費</option>
                    </select>
                    <textarea name="nickname" class="input_comment_text5" cols="50" rows="10" maxlength="100">
                  </textarea>
                </form>

            </div>

        </div>

    </body>

</html>
